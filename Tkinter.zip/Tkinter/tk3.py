import tkinter
from tkinter import *
import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
finestra = tk.Tk()
finestra.title("Preguntas")
txt = "Resposta: "


def ShowWindow():
    Pre1 = messagebox.askquestion("Pregunta1", "si o no")
    Pre2 = messagebox.askyesno("Pregunta2", "si o no")
    Pre3 = messagebox.askquestion("Pregunta3", "le gusta el azul:")
    
    Pregunta1 = tk.Label(finestra, text= txt + Preguntas(Pre1))
    Pregunta2 = tk.Label(finestra, text=txt + Preguntas(Pre2))
    Pregunta3 = tk.Label(finestra, text=txt + Preguntas(Pre3))
    
    Pregunta1.pack()
    Pregunta2.pack()
    Pregunta3.pack()


boton = tk.Button(finestra, text="Mostrar ventana", command=ShowWindow)
boton.pack()

def Preguntas(Rep):
    if  Rep == "yes":
        return "si"
    
    else: return "no"

finestra.mainloop()