from tkinter import *
import tkinter as tk
from tkinter import ttk
from tkinter import messagebox



finestra = tk.Tk()

quadre = tk.Entry(finestra, width=30)
quadre.grid(rowspan= 1, columnspan=6)
Res = 0

def delete():
    quadre.delete(0, tk.END)


def calculadora():
    text = quadre.get()
    if "+" in text:
        num = text.split("+")
        Res= int(num[0]) + int(num[1])
        delete()
        quadre.insert(0, Res)
    elif "-" in text:
        num = text.split("-")
        Res = int(num[0]) - int(num[1])
        delete()
        quadre.insert(0, Res)
    elif "*" in text:
        num = text.split("*")
        Res = int(num[0]) * int(num[1])
        delete()
        quadre.insert(0,Res)
    elif "/" in text:
        num = text.split("/")
        Res = int(num[0]) / int(num[1])
        delete()
        quadre.insert(0, Res)


button0 = Button(finestra, text="0",fg='#FFFFFF',bg='#5B4B4B',font='helvetica',borderwidth='4',width='8', command=lambda: ButtonPut(0))
button0.grid(row= 6, column=2)

button1 = Button(finestra, text="1",fg='#FFFFFF',bg='#5B4B4B',font='helvetica',borderwidth='4',width='8', command=lambda: ButtonPut(1))
button1.grid(row=5, column=1)

button2 = Button(finestra, text="2", fg='#FFFFFF',bg='#5B4B4B',font='helvetica',borderwidth='4',width='8', command=lambda: ButtonPut(2))
button2.grid(row=5, column= 2)

button3 = Button(finestra, text="3", fg='#FFFFFF',bg='#5B4B4B',font='helvetica',borderwidth='4',width='8', command=lambda: ButtonPut(3))
button3.grid(row=5, column=3)

button4 = Button(finestra, text="4", fg='#FFFFFF',bg='#5B4B4B',font='helvetica',borderwidth='4',width='8', command=lambda: ButtonPut(4))
button4.grid(row=4, column=1)

button5 = Button(finestra, text="5", fg='#FFFFFF',bg='#5B4B4B',font='helvetica',borderwidth='4',width='8', command=lambda: ButtonPut(5))
button5.grid(row=4, column=2)

button6 = Button(finestra, text="6", fg='#FFFFFF',bg='#5B4B4B',font='helvetica',borderwidth='4',width='8', command=lambda: ButtonPut(6))
button6.grid(row=4, column=3)

button7 = Button(finestra, text="7", fg='#FFFFFF',bg='#5B4B4B',font='helvetica',borderwidth='4',width='8', command=lambda: ButtonPut(7))
button7.grid(row=3, column=1)

button8 = Button(finestra, text="8", fg='#FFFFFF',bg='#5B4B4B',font='helvetica',borderwidth='4',width='8', command=lambda: ButtonPut(8))
button8.grid(row=3, column=2)

button9 = Button(finestra, text="9", fg='#FFFFFF',bg='#5B4B4B',font='helvetica',borderwidth='4',width='8', command=lambda: ButtonPut(9))
button9.grid(row=3, column=3)

button_delete = Button(finestra, text= "C", fg='#FFFFFF',bg='#5B4B4B',font='helvetica',borderwidth='4',width='8', command= delete)
button_delete.grid(row= 6, column=1)

button_sum = Button(finestra, text= "+", fg='#FFFFFF',bg='#5B4B4B',font='helvetica',borderwidth='4',width='8', command=lambda: ButtonPut("+"))
button_sum.grid(row = 7, column=1)

button_resta = Button(finestra, text="-", fg='#FFFFFF',bg='#5B4B4B',font='helvetica',borderwidth='4',width='8', command=lambda: ButtonPut("-"))
button_resta.grid(row=7, column=2)

button_igual = Button(finestra, text= "=", fg='#FFFFFF',bg='#5B4B4B',font='helvetica',borderwidth='4',width='8', command=calculadora)
button_igual.grid(rows=8, columnspan=4)

button_multiplicar = Button(finestra, text= "*", fg='#FFFFFF',bg='#5B4B4B',font='helvetica',borderwidth='4',width='8', command=lambda: ButtonPut("*"))
button_multiplicar.grid(row=7, column=3)

button_dividir = Button(finestra, text= "/", fg='#FFFFFF',bg='#5B4B4B',font='helvetica',borderwidth='4',width='8', command=lambda: ButtonPut("/"))
button_dividir.grid(row=6, column=3)



def ButtonPut(i):
    quadre.insert(tk.END, i)
    finestra.grid(rowspan= 8,columnspan= 5)



finestra.mainloop()