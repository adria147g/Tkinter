from tkinter import *
import tkinter as tk
from tkinter import ttk
from PIL import ImageTk,Image


finestra  = tk.Tk()
finestra.geometry("500x500")
finestra.iconbitmap("Interfaces\Pyhton\Tkinter\icon.ico")
la_meva_llista = ['p1.jpg','p2.jpg','p3.jpg','p4.jpg','p5.jpg',] 

aimagen = 0
Firstimg = 0


def imagenAnterior( ):
    global aimagen
    global Firstimg

    removeimg()
    
    if aimagen >= 0 and aimagen <= 5:
    
        image1 = ImageTk.PhotoImage(Image.open(la_meva_llista[aimagen]))
        
        test = ImageTk.PhotoImage(image1)  
        label1 = ttk.Label(image=test)
        label1.imag = test
        label1.place(x=150 ,y = 100)
    if aimagen >=0 and aimagen <5:
        aimagen -= 1
    contador()
    
 
def imagenSiguiente( ):
    global aimagen
    global label1
    removeimg()
    
    if aimagen >= 0 and aimagen <= 5:
        image1 = Image.open(la_meva_llista[aimagen])
        test = ImageTk.PhotoImage(ImageTk.PhotoImage(image1)) 
        label1 = ttk.Label(finestra,image=test)
        label1.place()
        label1.imag = test
        label1.place(x=150 ,y = 100)    
        
    if aimagen >=0 and aimagen <5:
        aimagen += 1
    contador()
    
        
        
def removeimg ():
    global Firstimg
    if Firstimg >= 1 and aimagen != 5 and aimagen != 0:
        label1.place_forget()
    Firstimg += 1

def contador ():
    global la_meva_llista
    nlista = len(la_meva_llista)
    
    text2 = Label(finestra,text=(aimagen ,"/",nlista))
    text2.place(x=400, y=400) 
    
    
     


contador()
Exit = Button(finestra,command=finestra.quit,text="EXIT",fg='#FFFFFF',bg='#5B4B4B',font='helvetica',borderwidth='4',width='8')
Anterior = Button(finestra,command=imagenAnterior,text="Anterior",fg='#FFFFFF',bg='#5B4B4B',font='helvetica',borderwidth='4',width='8')
Siguiente = Button(finestra,command=imagenSiguiente,text="Siguiente",fg='#FFFFFF',bg='#5B4B4B',font='helvetica',borderwidth='4',width='8')


Exit.place(x=200, y=400)
Anterior.place(x=100, y=400)
Siguiente.place(x=300, y=400)
finestra.mainloop()
